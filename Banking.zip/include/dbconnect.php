<?php 
   
     $host="sql210.epizy.com";
	 $username="epiz_26978208";
	 $password="PbubaAKCb7TV";
	 $db_name="epiz_26978208_banking";
	 
	 
	 $conn=mysqli_connect("$host","$username","$password") or die("cannot connect");
	 
	 mysqli_select_db($conn,"$db_name") or die("cannot select DB");
?>